package sample;

public class SelfIntroduction {
	
	public static void main(String[] args) {
		
		//氏名		
		String name = "山田花子";
		//年齢
		int age = 25;
		//趣味
		String hobby = "映画鑑賞";
	
		/*
		 *自己紹介文を出力する処理
		 *2行以上コメントする時はこっちのコメントアウト を使う
		 */
		
		System.out.println("私の名前は" + name + "です。");
		System.out.println("年齢は" + age + "歳です。");
		System.out.println("趣味は" + hobby + "です。");
		
	}
}
